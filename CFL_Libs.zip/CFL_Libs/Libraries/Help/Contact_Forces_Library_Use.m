%% Using the Simscape Multibody Contact Forces Library
% 
% Copyright 2014-2018 The MathWorks, Inc.



%% 
% 
% <<Contact_Forces_Library_Use_Help1_IMAGE.png>>

%% 
% 
% <<Contact_Forces_Library_Use_Help2_IMAGE.png>>

%% 
%
